﻿using Grpc.Core;
using Grpc.Net.Client;
using GrpcMessageCounter;

var channel = GrpcChannel.ForAddress("http://localhost:5000");
var client = new MessageService.MessageServiceClient(channel);

using var call = client.StreamMessages();

var responseTask = Task.Run(async () =>
{
    await foreach (var response in call.ResponseStream.ReadAllAsync())
    {
        Console.WriteLine($"Сервер: '{response.Echo}', всього повідомлень: {response.TotalReceived}");
    }
});

while (true)
{
    Console.Write("Введи повідомлення (або Enter для завершення): ");
    var input = Console.ReadLine();
    if (string.IsNullOrWhiteSpace(input))
        break;

    await call.RequestStream.WriteAsync(new MessageRequest { Content = input });
}

await call.RequestStream.CompleteAsync();
await responseTask;
